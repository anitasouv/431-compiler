#!/bin/bash

javac *.java ast/*.java cfg/*.java llvm/*.java arm/*.java
